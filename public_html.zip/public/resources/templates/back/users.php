


                    <div class="col-lg-12">
                      

                        <h2 class="page-header">
                            Users
                         
                        </h2>


                        <h3 class="bg-success"><?php display_message(); ?></h3>

                          <p class="bg-success">
                            
                        </p>

                        <a href="index.php?add_user" class="btn btn-primary" name="add_user">Add User</a>


                        <div class="col-md-12">

                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                    
                                        <th>Username</th>
                                        <th>Email</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php show_users();?>
                                

                                    <tr>

                                     
                                    </tr>


                               


                                    
                                    
                                </tbody>
                            </table> <!--End of Table-->
                        

                        </div>










                        
                    </div>
    






